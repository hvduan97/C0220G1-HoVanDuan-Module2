package com.codegym.service;

import com.codegym.entity.Role;

import java.util.List;

public interface RoleService {
    List<Role> findAll();
}
